## Machine Learning 2
- [House Prices Markdown](/ML2_Team4_Final_RMD.html)
  - [Code in R](/ML2_Team4_Final_RMD.Rmd)

- [Slides](/HousePrices.pptx)
- [Notebook Critiques](/NotebookCritiques.docx)
